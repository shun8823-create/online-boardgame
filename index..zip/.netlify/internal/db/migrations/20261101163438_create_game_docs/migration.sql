CREATE TABLE "game_docs" (
	"path" text PRIMARY KEY,
	"parent" text NOT NULL,
	"data" jsonb NOT NULL,
	"updated_at" bigint NOT NULL
);
--> statement-breakpoint
CREATE INDEX "game_docs_parent_idx" ON "game_docs" ("parent","path");