/* オンライン対戦用ストア（Netlify Functions /api/store を Firestore 風の API で包む）
   ゲーム本体は db.doc(path) / db.collection(path) の get・set・update・delete・onSnapshot を使う。
   リアルタイム通知はポーリングで実現し、自分の書き込み直後は即座に再取得して遅延を抑える。 */
(function () {
  'use strict';
  const POLL_MS = 800;
  const watchers = new Map(); // path -> Set<kick()>

  async function call(body) {
    let res;
    try {
      res = await fetch('/api/store', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
    } catch (e) { const err = new Error('ネットワークに接続できません'); err.code = 'unavailable'; throw err; }
    const json = await res.json().catch(() => ({}));
    if (!res.ok) { const err = new Error(json.code || 'HTTP ' + res.status); err.code = json.code || 'http-' + res.status; throw err; }
    return json;
  }

  function kick(path) {
    const parent = path.slice(0, path.lastIndexOf('/'));
    for (const p of [path, parent]) (watchers.get(p) || []).forEach(f => f());
  }

  function watch(path, poll, onErr) {
    let stopped = false, timer = null, busy = false, again = false, fails = 0, reported = false;
    const run = async () => {
      if (stopped) return;
      if (busy) { again = true; return; }
      busy = true; clearTimeout(timer);
      try { await poll(); fails = 0; }
      catch (e) { if (++fails >= 5 && !reported && onErr) { reported = true; onErr(e); } }
      busy = false;
      if (stopped) return;
      if (again) { again = false; run(); } else timer = setTimeout(run, POLL_MS);
    };
    if (!watchers.has(path)) watchers.set(path, new Set());
    watchers.get(path).add(run);
    run();
    return () => { stopped = true; clearTimeout(timer); const s = watchers.get(path); if (s) { s.delete(run); if (!s.size) watchers.delete(path); } };
  }

  const snap = (id, r) => ({ id, exists: !!r.exists, data: () => r.data });

  function doc(path) {
    const id = path.slice(path.lastIndexOf('/') + 1);
    return {
      id,
      async get() { return snap(id, await call({ op: 'get', path })); },
      async set(data) { await call({ op: 'set', path, data }); kick(path); },
      async update(data) { await call({ op: 'update', path, data }); kick(path); },
      async delete() { await call({ op: 'delete', path }); kick(path); },
      onSnapshot(cb, onErr) {
        let last;
        return watch(path, async () => {
          const r = await call({ op: 'get', path });
          const key = JSON.stringify(r);
          if (key !== last) { last = key; cb(snap(id, r)); }
        }, onErr);
      },
    };
  }

  function collection(path) {
    const toDocs = docs => docs.map(d => ({ id: d.id, exists: true, data: () => d.data }));
    return {
      doc: id => doc(path + '/' + id),
      async get() { return { docs: toDocs((await call({ op: 'list', path })).docs) }; },
      onSnapshot(cb, onErr) {
        let after = null, first = true;
        // 新しく届いたドキュメントだけを ID 順に渡す（初回は空でも必ず1回呼ぶ）
        return watch(path, async () => {
          const { docs } = await call({ op: 'list', path, after });
          if (docs.length) after = docs[docs.length - 1].id;
          if (docs.length || first) { first = false; cb({ docs: toDocs(docs) }); }
        }, onErr);
      },
    };
  }

  window.onlineDB = { doc, collection };
})();
